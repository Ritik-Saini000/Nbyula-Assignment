const Footer = () => {
  return (
    <div
      style={{
        textAlign: "center",
        marginBottom: 10,
      }}
    >
      Made with ♥ by{" "}
      <a
        href="https://www.youtube.com/roadsidecoder"
        style={{ cursor: "pointer" }}
      >
        Roadside Coder
      </a>
    </div>
  );
};

export default Footer;
